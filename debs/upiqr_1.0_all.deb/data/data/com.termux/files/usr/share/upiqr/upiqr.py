import qrcode
import smtplib
from email.message import EmailMessage
import pyfiglet
from termcolor import colored
import re
import dns.resolver

def is_valid_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

def domain_exists(email):
    try:
        domain = email.split('@')[1]
        dns.resolver.resolve(domain, 'MX')
        return True
    except:
        return False

def generate_upi_qr_terminal(upi_id, name, amount, note, filename='upi_qr.png'):
    upi_uri = f"upi://pay?pa={upi_id}&pn={name}&am={amount}&cu=INR&tn={note}"

    qr = qrcode.QRCode(box_size=2, border=1)
    qr.add_data(upi_uri)
    qr.make(fit=True)

    img = qr.make_image(fill="black", back_color="white")
    img.save(filename)

    qr_matrix = qr.get_matrix()
    print(colored("\n📱 Scan this QR Code with any UPI app\n", "cyan"))
    for row in qr_matrix:
        print("".join(['██' if cell else '  ' for cell in row]))

    return upi_uri, filename

def send_email_smtp(sender_email, sender_password, recipient_email, upi_uri, qr_file):
    try:
        msg = EmailMessage()
        msg['Subject'] = '✅ UPI QR Code Ready'
        msg['From'] = sender_email
        msg['To'] = recipient_email
        msg.set_content(
            f"Hello,\n\nYour UPI QR code has been generated.\n\nUPI Payment Link: {upi_uri}\n\nQR code is attached as an image.\n\nRegards,\nUPI QR Generator"
        )

        with open(qr_file, 'rb') as f:
            img_data = f.read()
            msg.add_attachment(img_data, maintype='image', subtype='png', filename=qr_file)

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(sender_email, sender_password)
            smtp.send_message(msg)

        print(colored("\n📧 Success: Email sent with QR code image!", "green"))

    except Exception as e:
        print(colored(f"\n❌ Error sending email: {e}", "red"))

if __name__ == "__main__":
    print(colored(pyfiglet.figlet_format("UPI QR Gen", font="slant"), "blue"))

    upi_id = input("Enter your UPI ID (e.g., name@upi): ").strip()
    name = input("Enter Payee Name: ").strip()
    amount = input("Enter Amount (INR): ").strip()
    note = input("Enter Payment Note: ").strip()

    sender_email = input("Enter your Gmail address: ").strip()
    sender_password = input("Enter your App Password: ").strip()
    recipient_email = input("Enter recipient email: ").strip()

    if not is_valid_email(recipient_email) or not domain_exists(recipient_email):
        print(colored("❌ Invalid or unreachable email address.", "red"))
        exit()

    upi_uri, qr_file = generate_upi_qr_terminal(upi_id, name, amount, note)
    send_email_smtp(sender_email, sender_password, recipient_email, upi_uri, qr_file)
